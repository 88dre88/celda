﻿using UnityEngine;
using System.Collections;

public class Puntos : MonoBehaviour {

	//Puntos iniciales
	public int puntos = 0;
}
