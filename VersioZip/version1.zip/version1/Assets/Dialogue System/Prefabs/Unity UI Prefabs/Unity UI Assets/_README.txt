/*
This folder contains Unity-provided assets found in the 
Unity 4.6 UI Beta Test Project.
*/