/*

*** To use link.xml, move it into the root Assets folder. ***

The link.xml file in this folder allows iOS Pro users to build Dialogue System
projects with Stripping Level set to "Strip assemblies" or "Strip ByteCode".
The Dialogue System uses the System DLLs, so it doesn't support
"Use micro mscorlib" stripping.

Read more about iOS code stripping at:
http://docs.unity3d.com/Documentation/Manual/iphone-playerSizeOptimization.html
*/