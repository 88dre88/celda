/*
This folder contains a large selection of legacy Unity GUI-based dialogue UIs that you can use
to set the Dialogue System's appearance in your project. You can delete any you don't need, but don't
delete the Default folder; this contains the default fallback UI that the Dialogue System uses if it
can't access your regular UI.
*/