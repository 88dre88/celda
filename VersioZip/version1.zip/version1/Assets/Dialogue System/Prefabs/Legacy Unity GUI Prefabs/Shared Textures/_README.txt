/*
Test Portrait from: http://www.clker.com/clipart-211776.html
Public domain by KELLY: http://www.clker.com/profile-90718.html

Mouse (QTE) from: http://www.clker.com/clipart-2850.html
Public domain by OCAL: http://www.clker.com/profile-1068.html
*/
