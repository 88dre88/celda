Necromancer GUI
March 1st 2011
Art/programing: Jason Wentzel
Fonts: Kevin King

jc_wentzel@ironboundstudios.com

This GUI is pretty much plug-n play. Although you can use it as a striate replacement for the standard skin, it does have a lot of custom styles. You�ll need to add script to use most of them. This package includes a javascript with some examples of how to use the custom styles. If you add to this skin please share your additions with the community.
Have fun.