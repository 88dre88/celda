/*
Theater masks used in Circle UI by lyo: http://www.clker.com/clipart-30136.html
*/