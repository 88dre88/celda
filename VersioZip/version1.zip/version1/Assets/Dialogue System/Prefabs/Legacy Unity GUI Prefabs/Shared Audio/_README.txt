/*
hover: http://www.freesound.org/people/senitiel/sounds/209058/
click: http://www.freesound.org/people/fins/sounds/146718/
typewriter: http://www.freesound.org/people/ddohler/sounds/9098/
*/
