/*
Dialogue System Camera Angle Studio Scene

This folder contains a scene that you might find helpful when designing camera angles. It contains
a subject in a three-point light setup. To design camera angles, open the scene and select the menu
item Window > Dialogue System > Tools > Camera Angle Editor.

For more instructions on the Camera Angle Editor, please see the documentation.
*/
