/*
Dialogue System Lua Example

This folder contains a scene that acts as a command line Lua interpreter.
When you play the scene, you can enter Lua commands and see the return values.
*/
