/*
Sprite by Shepardskin: https://twitter.com/Shepardskin
*/