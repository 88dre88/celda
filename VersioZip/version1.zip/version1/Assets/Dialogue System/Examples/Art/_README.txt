/*
This folder contains assets and prefabs used by the example scenes.
*/