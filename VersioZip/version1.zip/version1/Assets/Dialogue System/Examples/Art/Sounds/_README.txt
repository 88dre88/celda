/*
Sound credits:

Explosion: http://www.freesound.org/people/sarge4267/sounds/102734/
Bonecrush: http://www.freesound.org/people/satanicupsman/sounds/144015/
Pulse Rifle: http://www.freesound.org/people/Andromadax24/sounds/169775/
*/