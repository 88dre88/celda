/*
The Dialogue System's main example scenes were built with legacy Unity GUI
dialogue UIs. Since the Dialogue System is GUI system-independent, you can
easily swap out the dialogue UIs with Unity UI versions.

The scenes in this folder use Unity UI dialogue UIs.

Generic UI Example Scene uses all of the generic UI prefabs.

The "SF" scenes use the SF UI theme.
*/