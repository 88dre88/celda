/*
Dialogue System Save/Load System Example

*IMPORTANT*
BEFORE RUNNING THIS EXAMPLE:
You must add the scenes "Airlock" and "Server Room" located in the Scenes subfolder
to your project's build settings. Otherwise you won't be able to move between levels.

This scene demonstrates saving and loading game data that includes loading the level
that the player saved in.

Start in the Airlock scene.

Press Escape to open the main menu, which contains buttons to save and load the game.

There is also a Terminal in the Airlock scene that demonstrates how to use the
GameSaver component to save and load without scripting.

*/