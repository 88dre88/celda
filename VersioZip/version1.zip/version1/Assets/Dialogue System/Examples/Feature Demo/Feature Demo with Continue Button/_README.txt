/*
Dialogue System Feature Demo - With Continue Button

This folder contains a variation of the Feature Demo scene that requires the player to
click a Continue button to progress past lines of dialogue. It uses a UI in the hierarchy
rather than a prefab. This UI has continue buttons for the PC's and NPC's subtitles.
The Dialogue Manager's Wait for Continue Button is ticked.
*/
