/*
Dialogue System Feature Demo - With Menu Text

This folder contains a variation of the Feature Demo scene that demonstrate uses shorter Menu Text
paraphrases for the player response menu. The player's selection is then expanded into the full
Dialogue Text. Note the use of "Show PC Subtitles During Line", which is ticked on the Dialogue
Manager. This shows the full Dialogue Text. If you instead have a voice-acted cutscene sequence
and don't want to display subtitles, you can untick this. The NPC's next line won't occur until
the voice-acted sequence is done, even though it isn't displaying any subtitle text.
*/
