/*
This folder contains scripts used by the example scenes. 
You may find them useful in your own projects, too.
They're also accessible through the menu Window > Dialogue System > Component > Supplemental.

Note: Prior to version 1.1.4, these scripts were located in Examples/Scripts.
*/
