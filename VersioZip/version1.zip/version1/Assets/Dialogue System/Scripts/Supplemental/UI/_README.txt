/*
This folder contains new Unity UI implementations of the following 
user interface elements:

- Bark UI
- Dialogue UI (alerts, conversations, and QTEs)
- Quest Log Window
- Selector

Dialogue System/Examples/Unity UI Examples contains example scenes
that use Unity UI.
*/