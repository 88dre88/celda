/*
Complete documentation is available online at:

http://www.pixelcrushers.com/dialogue_system/manual/html



You can also access this URL through Window > Dialogue System > Help.

To download an offline copy:  http://pixelcrushers.com/dialogue_system/manual/Documentation.zip
*/