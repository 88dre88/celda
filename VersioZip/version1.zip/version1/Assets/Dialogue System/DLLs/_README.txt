/*
This folder contains precompiled DLLs of the Dialogue System and 
Lua Interpreter source code. These precompiled DLLs will significantly
decrease your build times, allowing you to iterate on ideas faster.

Complete source code is provided in the Scripts folder. The source code
is in a unitypackage to prevent conflicts with the DLLs. To unpack the
source code, please see the Installation section of the user manual.
*/